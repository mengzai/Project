# -*- coding: utf-8 -*-
"""
    echarts.option
    ~~~~~~~~~~~~~~
    Options for chart
"""
import json

class Base(object):
    """
    Base Class
    Args:object
    Returns:return string text of the classreturn string text of the class
    """
    def __str__(self):
        """JSON stringify format data."""
        return json.dumps(self.json)

    def __getitem__(self, key):
        return self.json.get(key)

    def keys(self):
        return self.json.keys()

    @property
    def json(self):
        raise NotImplementedError

class Axis(Base):
    """Echart's component
    Args:
         type:a string in ['category', 'value', 'time']
         position:a string in ('bottom', 'top', 'left', 'right')
         name:name
         data:value passed by user
         kwargs:other args
    methods:__init__,__repr__,json
    Returns:return ths json string of the class

    """
    def __init__(self,type=None,position=None, name=None, data=None, show=None,param=None,**kwargs):
        assert type in (None,'category', 'value', 'time')
        self.type = type
        assert position in (None,'bottom', 'top', 'left', 'right')
        self.position = position
        self.name = name
        self.data = data or []
        self.show=show
        self.param=param
        self._kwargs = kwargs

    def __repr__(self):
        return 'Axis<%s/%s>' % (self.type, self.position)

    @property
    def json(self):
        """JSON format data."""
        json = dict(
            type=self.type
        )
        if self.show:
            json['show'] = self.show

        if self.position:
            json['position'] = self.position

        if self.data:
            json['data'] = self.data

        if self.name:
            json['name'] = self.name

        if self._kwargs:
            json.update(self._kwargs)
        return json


class Legend(Base):
    """Legend section for Echart.
    Args:
         data:value passed by user
         orient:a string in ('horizontal', 'vertical')
         position:a tuple  representing  values of the axis
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, data, orient=None, position=None, **kwargs):
        self.data = data
        assert orient in (None,'horizontal', 'vertical')
        self.orient = orient
        self.position = position
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {}
        if self.data:
            json['data']=self.data

        if self.orient:
            json['orient']=self.orient

        if self.position:
            json['x']=self.position[0]
            json['y'] = self.position[1]

        if self._kwargs:
            json.update(self._kwargs)
        return json


class DataRange(Base):
    """DataRange section for Echart.
    Args:
         _range: tuple  representing  the min val~max val
         position:a tuple  representing  values of the axis
         text:description
         calculable:true or false
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, _range=None, position=None, text=None, calculable='true', **kwargs):
        if not position:
            position = ['left', 'bottom']
        if not _range:
            _range = [0, 0]
        if not text:
            text = ['高', '低']
        self.position = position
        self._range = _range
        self.text = text
        self._kwargs = kwargs
        self.calculable = calculable



    @property
    def json(self):
        """JSON format data."""
        json = {
            'min': self._range[0],
            'max': self._range[1],
            'x': self.position[0],
            'y': self.position[1],
            'text': self.text,
            'calculable': self.calculable
        }

        if self._kwargs:
            json.update(self._kwargs)
        return json


class Title(Base):
    """Title of the figure 
    Args:
         text:the title of the figure
         subtext:the subtitle of the figure
         x,y:the position of the title
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self,text='',subtext='',x=None,y=None,**kwargs):
        self.text=text
        self.subtext = subtext
        self.x = x
        self.y=y
        self._kwargs=kwargs
    @property
    def json(self):
        """JSON format data."""
        json = dict(
            text=self.text,
            subtext=self.subtext
        )
        if  self.x:
            json['x']=self.x
        if  self.y:
            json['y']=self.y
        if self._kwargs:
            json.update(self._kwargs)
        return json


class Tooltip(Base):
    """A tooltip when hovering.
    Args:
         trigger:a string in ('axis', 'item')
         formatter:user defined
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """

    def __init__(self, trigger='item',formatter=None,**kwargs):
        assert trigger in ('axis', 'item')
        self.trigger = trigger
        self.formatter=formatter
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        if self.formatter==None:
            json = {'trigger': self.trigger}
        else:
            json = {'trigger': self.trigger,'formatter':self.formatter}
        if self._kwargs:
            json.update(self._kwargs)
        return json

class ItemStyle(Base):
    """ItemStyle 
    Args:
         normal:obj
         emphasis:obj
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, normal=None, emphasis=None, **kwargs):
        self.normal = normal
        self.emphasis = emphasis
        self._kwargs = kwargs
        # if not self.normal:
        #     self.normal= {'label':{'show':'true'}}##暂时这么设定
        # if not self.emphasis:
        #     self.emphasis={'label':{'show':'true'}}
    @property
    def json(self):
        """JSON format data."""
        json = {}
        if self.normal:
            json['normal']=self.normal
        if self.emphasis:
            json['emphasis']=self.emphasis
        if self._kwargs:
            json.update(self._kwargs)
        return json

class Series(Base):
    """Data series holding. 
    Args:
         _type:the type of the Series
         name:Series's name
         mapType:the type of the map
         itemStyle:obj
         data:data passed by user
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, _type, name=None, mapType=None,itemStyle=None,data=None, markPoint=None,markLine=None,**kwargs):
        types = (
            'bar', 'boxplot', 'candlestick', 'chord', 'effectScatter',
            'eventRiver', 'force', 'funnel', 'gauge', 'graph', 'heatmap',
            'k', 'line', 'lines', 'map', 'parallel', 'pie', 'radar',
            'sankey', 'scatter', 'tree', 'treemap', 'venn', 'wordCloud'
        )

        assert _type in types
        self._type = _type
        self.name = name
        self.mapType = mapType
        self.itemStyle = itemStyle
        self.data = data or []
        self.markPoint=markPoint
        self.markLine=markLine
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {
            'type': self._type,
            'data': self.data,
        }
        if self.name:
            json['name'] = self.name
        if self.mapType:
            json['mapType'] = self.mapType
        if self.itemStyle:
            if type(self.itemStyle)==type({}):
                json['itemStyle'] = self.itemStyle
            else:
                json['itemStyle'] = self.itemStyle.json
        if self.markPoint:
            json['markPoint']=self.markPoint.json
        if self.markLine:
            json['markLine']=self.markLine.json
        if self._kwargs:
            json.update(self._kwargs)
        return json

class Mark(Base):
    """Mark
    Args:
         show:true or false,weather display the component
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, show='true',**kwargs):
        self.show=show
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {
            'show': self.show
        }
        if self._kwargs:
            json.update(self._kwargs)
        return json

class DataView(Base):
    """DataView
    Args:
         show:true or false,weather display the component
         readOnly:true or false
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, show='true',readOnly='false',**kwargs):
        self.show=show
        self.readOnly=readOnly
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {
            'show': self.show,
            'readOnly': self.readOnly
        }
        if self._kwargs:
            json.update(self._kwargs)
        return json

class MagicType(Base):
    """MagicType
    Args:
         show:true or false,weather display the component
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, show='true',type=None,**kwargs):
        self.show=show
        self.type=type
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {
            'show': self.show
        }
        if self.type:
            json['type']=self.type
        if self._kwargs:
            json.update(self._kwargs)
        return json

class Restore(Base):
    """Restore 
    Args:
         show:true or false,weather display the component
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, show='true',**kwargs):
        self.show=show
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {
            'show': self.show
        }
        if self._kwargs:
            json.update(self._kwargs)
        return json

class SaveAsImage(Base):
    """SaveAsImage
    Args:
         show:true or false,weather display the component
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, show='true',**kwargs):
        self.show=show
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {
            'show': self.show
        }
        if self._kwargs:
            json.update(self._kwargs)
        return json

class Feature(Base):
    """Feature. 
    Args:
         mark:obj
         dataView:obj
         restore:obj
         saveAsImage:obj
         magicType:obj
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, mark=None,dataView=None,restore=None,saveAsImage=None,magicType=None,**kwargs):
        if not mark:
            mark=Mark().json
        if not dataView:
            dataView=DataView().json
        if not restore:
            restore=Restore().json
        if not saveAsImage:
            saveAsImage=SaveAsImage().json

        self.mark=mark
        self.dataView=dataView
        self.restore=restore
        self.saveAsImage=saveAsImage
        self.magicType=magicType
        self._kwargs=kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {
            'mark': self.mark,
            'dataView': self.dataView,
            'restore': self.restore,
            'saveAsImage':self.saveAsImage
        }
        if self.magicType:
            json['mapType']=self.magicType.json
        if self._kwargs:
            json.update(self._kwargs)
        return json



class Toolbox(Base):
    """A toolbox for visitor. 
    Args:
         orient:direction, a string in ('horizontal', 'vertical')
         position:a component's position
         show:true or false,weather display the component
         feature:other obj
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, orient='vertical', position=None, show='true',feature={},**kwargs):
        assert orient in ('horizontal', 'vertical')
        self.orient = orient
        if not position:
            position = ('right', 'top')
        self.position = position
        self.show=show
        self._kwargs = kwargs
        if feature=={}:
            feature={}
        self.feature=feature

    @property
    def json(self):
        """JSON format data."""
        json = {
            'orient': self.orient,
            'x': self.position[0],
            'y': self.position[1],
            'show':self.show,
            'feature':self.feature.json
        }
        if self._kwargs:
            json.update(self._kwargs)
        return json

class MapTypeControl(Base):
    """MapTypeControl
    Args:
         china:the type pf the map figure
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, china='true',**kwargs):
        self.china = china
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data"""
        json = {
            "china": self.china
        }
        if self._kwargs:
            json.update(self._kwargs)
        return json

class RoamController(Base):
    """RoamController
    Args:
         mapTypeControl: object of MapTypeControl.cls
         show:true of false
         x:a value representing  x axis
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, mapTypeControl=None,show='true',x='right',**kwargs):
        self.show = show
        self.x = x
        self.mapTypeControl =mapTypeControl
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data"""
        json = {
            "show": self.show,
            "x": self.x,
            "mapTypeControl": self.mapTypeControl,
        }
        if self._kwargs:
            json.update(self._kwargs)
        return json        
    
class VisualMap(Base):
    """maps data to visual channels.
    Args:
         type: a string  in ("continuous", "piecewise")
         min:min val
         max:max val
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, range=[0,0],position=['left','top'],text=['高','低'],calculable='true',type=None,**kwargs):
        assert type in (None,"continuous", "piecewise")
        self.type = type
        if range:
            min=range[0]
            max=range[1]
        self.min = min
        self.max = max
        if position:
            left=position[0]
            top=position[1]
        self.left=left
        self.top=top
        self.text=text
        self.calculable=calculable
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data"""
        json = {
            # "type": self.type,
            'min': self.min,
            'max': self.max,
            'left':self.left,
            'top': self.top,
            'text':self.text,
            'calculable':self.calculable

        }
        if self._kwargs:
            json.update(self._kwargs)
        return json



class MarkPoint(Base):
    """MarkPoint
    Args:
         data:data
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, data=None,**kwargs):
        self.data=data
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {}

        if not self.data:
            self.data=[{'type':'max','name':'最大值'},{'type':'min','name':'最小值'}]
        json['data']=self.data
        if self._kwargs:
            json.update(self._kwargs)
        return json

class MarkLine(Base):
    """MarkLine
    Args:
         data:data
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, data=None,**kwargs):
        self.data=data
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {}

        if not self.data:
            self.data=[{'type':'average','name':'平均值'}]
        json['data']=self.data
        if self._kwargs:
            json.update(self._kwargs)
        return json

class Data(Base):
    """Data
    Args:
         type:type
         name:name
         kwargs:other args
    methods:__init__,json
    Returns:return ths json string of the class
    """
    def __init__(self, type=None,name=None,**kwargs):
        self.type=type
        self.name=name
        self._kwargs = kwargs

    @property
    def json(self):
        """JSON format data."""
        json = {}

        if self.type:
            json['type']=self.type
        if self.name:
            json['name']=self.name
        if self._kwargs:
            json.update(self._kwargs)
        return json