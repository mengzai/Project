# -*- coding: utf-8 -*-
import os,sys
parentdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,parentdir)

from echarts import *
from nose.tools import raises
import unittest

class TestChart(unittest.TestCase):
    """
    part of the project's testcase
    """
    ##初始化工作 
    def setUp(self):
        pass
    #退出清理工作    
    def tearDown(self):
        pass 
    def test_axis(self):
        chart = Echart()
        self.assertEquals(len(chart.json['xAxis'][0]),0)
        # assert len(chart.json['yAxis'][0]) == 0
        chart.use(Axis('category', 'bottom', 'proportion', inverse=True))
        assert chart.json['xAxis']
        chart.use(Axis('category', 'left', 'proportion', inverse=True))
        assert chart.json['yAxis']
        map(repr, chart.x_axis)
    # @raises(AssertionError)
    def test_axis_assert_type(self):
        with self.assertRaises(AssertionError):
            Axis('nil', 'bottom', 'proportion', inverse=True)
    # @raises(AssertionError)
    def test_axis_assert_position(self):
        with self.assertRaises(AssertionError):
            Axis('cetegory', 'nil', 'proportion', inverse=True)

    def test_legend(self):
        chart = Echart()
        with self.assertRaises(AssertionError):
            chart.use(Legend(['Item1 Title'], 'xx'))
            chart.json['legend']['data']

    # @raises(AssertionError)
    def test_legend_assert_position(self):
        with self.assertRaises(AssertionError):
            Axis('cetegory', 'nil', 'proportion', inverse=True)

    def test_tooltip(self):
        chart = Echart()
        chart.use(Tooltip('item'))
        self.assertEquals(chart.json['tooltip']['trigger'],'item','test error')
        
    def test_toolbox(self):
        chart = Echart()
        chart.use(Toolbox('horizontal', show=True))
        self.assertEquals(chart.json['toolbox']['orient'],'horizontal','test error')
        self.assertTrue(chart.json['toolbox']['show'],'test error')

    # @raises(AssertionError)
    def test_toolbox_assert(self):
        with self.assertRaises(AssertionError):
            Toolbox('nil')

    # @raises(NotImplementedError)
    # def test_extra(self):
    #     str(Echart.__base__())

if __name__=='__main__':
    unittest.main()
    