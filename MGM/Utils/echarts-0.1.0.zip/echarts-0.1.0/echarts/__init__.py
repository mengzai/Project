# -*- coding: utf-8 -*-
"""
    echarts
    ~~~~~~~
    An Echarts options generator with Python.
    :copyright: (c) 2017 by gangfang <gangfang6@creditease.cn>.
    :license: CREDITEASE.
"""
import os
import json
import logging
import tempfile
import webbrowser
from option import *
from datastructure import *
from html import Html_text



__version__ = '0.1'
__release__ = '0.1.0'
__author__ = 'created by FG at time 2017.6,email:gangfang6@creditease.cn'

class Echart(Base):
    """Echart:entrance to the entire project
    Args:
         axis:
         series:series component
         kwargs:other args
    methods:__init__,use,json,data,_html,plot,save
    Returns:returns the json string of this obj

    """
    def __init__(self,axis=True,theme='macarons',**kwargs):
        #title, description=None,
        # self.title = {
        #     'text': title,
        #     'subtext': description,
        # }
        self.axis = axis
        if self.axis:
            self.x_axis = []
            self.y_axis = []
        self.series = []
        self.theme=theme
        self.kwargs = kwargs

        self.logger = logging.getLogger(__name__)

    def use(self,obj,param=None):##默认有个param作为参数控制外围的特性
        """
        use item of the echart
        :param obj: item of the echart
        """
        if isinstance(obj,Axis):
            if obj.param=='x':
                self.x_axis.append(obj)
            elif obj.param=='y':
                self.y_axis.append(obj)
        elif isinstance(obj,Title):
            self.title=obj
        elif isinstance(obj, Legend):
            self.legend = obj
        elif isinstance(obj, Tooltip):
            self.tooltip = obj
        elif isinstance(obj, Series):
            self.series.append(obj)
        elif isinstance(obj, Toolbox):
            self.toolbox = obj
        elif isinstance(obj, VisualMap):
            self.visualMap = obj
        elif isinstance(obj, DataRange):
            self.dataRange = obj
        elif isinstance(obj, RoamController):
            self.roamController = obj
        return self

    @property
    def data(self):
        return self.series
    
    @property
    def json(self):
        """
        generate echart's json string
        """
        """JSON format data."""
        json = {
            'series': list(map(dict, self.series)),
            'theme':self.theme
        }

        if self.axis:
            json['xAxis'] = list(map(dict, self.x_axis)) or [{}]
            json['yAxis'] = list(map(dict, self.y_axis)) or [{}]

        if hasattr(self, 'title'):
            json['title'] = self.title.json
        if hasattr(self, 'legend'):
            json['legend'] = self.legend.json
        if hasattr(self, 'tooltip'):
            json['tooltip'] = self.tooltip.json
        if hasattr(self, 'dataRange'):
            json['dataRange'] = self.dataRange.json
        if hasattr(self, 'toolbox'):
            json['toolbox'] = self.toolbox.json
        if hasattr(self, 'visualMap'):
            json['visualMap'] = self.visualMap.json
        json.update(self.kwargs)
        return json

    def _html(self):
        """
        replace the opt in html into json string
        """
        theme_str=self.json['theme']
        html_text=Html_text().html_text().replace('{{ theme }}',theme_str)
        return html_text.replace('{{ opt }}', json.dumps(self.json, indent=4))


    def plot(self, persist=True):
        """
        Plot into html file
        :param persist: persist output html to disk
        """
        with tempfile.NamedTemporaryFile(suffix='.html', delete=not persist) as fobj:
            fobj.write(self._html())
            # print self._html()
            fobj.flush()
            webbrowser.open('file://' + os.path.realpath(fobj.name))
            persist or raw_input('Press enter for continue')
                
    def save(self, path, name):
        """
        Save html file into project dir
        :param path: project dir
        :param name: html file name
        """
        if not os.path.exists(path):
            os.makedirs(path)
        with open(path+str(name)+".html", "w") as html_file:
            html_file.write(self._html())

'''
test case,下面是代码的测试部分
'''
import pandas as pd
import numpy as np

'''加载数据'''
def load_data(filename):
	return pd.read_csv(filename, error_bad_lines=False)

'''将series类型的数据转换为list'''
def df_to_list(df):
	df = df.tolist()
	res = []
	for each in df:
		vals = [k for k in str(each).split("|") if not pd.isnull(k) and k != 'nan' and k!= 'None' and k!="-999" and k!="" and k!="投资" and k!="理财" and k!="资产配置"]
		res += list(set(vals))
	return res

'''填充开户时间和生日：注意，这里面有些是缺失数据，所以用-999填充'''
def fill_opentime_birth_date(x):
    if pd.isnull(x):
        return -999
    else:
        return 2017 - int(str(x)[:4])

'''年龄的划分，这里有可能需要将年龄进一步的合并，特征是30-40岁之间的'''
def process_age(x):
    if x <= 30:
        return "<=30"
    elif x <= 40:
        return "<=40"
    elif x <= 50:
        return "<=50"
    elif x <= 60:
        return "<=60"
    else:
        return ">60"

'''处理客户级别的，将客户分成不同的级别'''
def process_customer_level(x):
    if (x <= 2 and x >= 1):
        return "<=2"
    elif x == 3:
        return "3"
    elif x >= 3:
        return "3+"

'''开户时间的处理'''
def process_open_time(x):
    if x >= 5:
        return "5+"
    else:
        return str(x)

'''处理浮点数的问题，保留两位小数，主要是因为round函数存在问题'''
def remove_2_xiaoshu(x):
    return '%.2f' % x

'''处理省市的问题'''
def process_province(x):
    jiangsu_str = "江苏省"
    zhejiang_str = "浙江省"
    beijing_str = "北京市"
    shanghai_str = "上海市"
    shandong_str = "山东省"
    guangdong_str = "广东省"
    if (x != jiangsu_str) and (x != zhejiang_str) and (x != beijing_str) and (x != shanghai_str) and (
        x != shandong_str):
        return 'other'
    else:
        return x

'''加载相应的数据，提取相应的数据特征'''
def load_data():
    import pandas as pd
    from collections import Counter
    import numpy as np
    from pandas import DataFrame
    from pandas import Series
    data_fir = "D:\\fg_workspace\\caifuduan\\final\\"

    '''step1:取出全量数据和mgm数据，并提取其中相应的数据特征'''
    mgm_data = pd.read_csv(data_fir + "final_version_data.csv")
    mgm_data = mgm_data[["ecif_id", "recommend_num", "sex", "birth_date", "ftrade", "fhighest_education", "customer_level",
         "province_name", "audit_status", "card_type", "customer_source", "fcustomer_status", "finvest_status",
         "open_time"]]
    all_data = pd.read_csv(data_fir + "MGM_feature_nv.csv")
    all_data = all_data[["ecif_id", "recommend_num", "sex", "birth_date", "ftrade", "fhighest_education", "customer_level",
         "province_name", "audit_status", "card_type", "customer_source", "fcustomer_status", "finvest_status",
         "open_time"]]

    '''step2.1:处理全量数据和mgm数据中的open_time和age问题'''
    mgm_data['open_time'] = mgm_data['open_time'].apply(lambda x: 2017 - int(str(x)[:4]))
    mgm_data['age'] = mgm_data['birth_date'].apply(lambda x: 2017 - int(str(x)[:4]))
    mgm_data.drop('birth_date', axis=1, inplace=True)

    all_data['open_time'] = all_data['open_time'].apply(lambda x: fill_opentime_birth_date(x))
    all_data['age'] = all_data['birth_date'].apply(lambda x: fill_opentime_birth_date(x))
    all_data.drop('birth_date', axis=1, inplace=True)

    '''step2.2:处理全量数据中数据为空的问题，并填充数据'''
    for column in all_data.columns.tolist():
        all_data.loc[(all_data[column].isnull()), column] = -999

    '''step2.3:处理全量数据和mgm中ftrade以及fhighest_education==-10这部分，其实他们也是空的'''
    mgm_data.loc[(mgm_data['ftrade'] == -10), 'ftrade'] = -999
    mgm_data.loc[(mgm_data['fhighest_education'] == -10), 'fhighest_education'] = -999

    all_data.loc[(all_data['ftrade'] == -10), 'ftrade'] = -999
    all_data.loc[(all_data['fhighest_education'] == -10), 'fhighest_education'] = -999

    '''step2.4:处理全量数据和mgm数据中的customer_level和open_time,province_name以及age离散化的问题'''
    mgm_data['customer_level'] = mgm_data['customer_level'].apply(lambda x: process_customer_level(x))
    mgm_data['open_time'] = mgm_data['open_time'].apply(lambda x: process_open_time(x))
    mgm_data['province_name'] = mgm_data['province_name'].apply(lambda x: process_province(x))
    mgm_data['age'] = mgm_data['age'].apply(lambda x: process_age(x))

    all_data['customer_level'] = all_data['customer_level'].apply(lambda x: process_customer_level(x))
    all_data['open_time'] = all_data['open_time'].apply(lambda x: process_open_time(x))
    all_data['province_name'] = all_data['province_name'].apply(lambda x: process_province(x))
    all_data['age'] = all_data['age'].apply(lambda x: process_age(x))

    return mgm_data,all_data

'''将既有数字又有类别型的数据全部转换为类别型，并去除数字型中相应的浮点数'''
def convert_to_category(x):
    if "." in x:
        val=x[:x.index('.')]
        # val='%f' % x
        return "'"+str(val)+"'"
    else:
        return x
    
'''画出财富端的图表'''
def plot_caifuduan_figure():
    import numpy as np
    '''load data'''
    mgm_data, all_data=load_data()
    '''data description'''
    print mgm_data.head()
    print all_data.head()
    '''plot figure'''
    diff_list = ["sex", "age", "ftrade", "fhighest_education", "customer_level", "province_name", "audit_status","card_type","customer_source","fcustomer_status","finvest_status","open_time"]

    '''define data range'''
    # mgm_data_3_gt = mgm_data[mgm_data['recommend_num']>=3]
    # mgm_data_3_lt = mgm_data[mgm_data['recommend_num']<3]
    mgm_data_4_gt = mgm_data[mgm_data['recommend_num']>=4]
    mgm_data_4_lt = mgm_data[mgm_data['recommend_num']<4]
    all_data=all_data

    nototation_list=['推荐人数>=4','推荐人数<4','推荐人数(整体)']
    data_list=[mgm_data_4_gt,mgm_data_4_lt,all_data]
    # mgm_data_5_gt= mgm_data[mgm_data['recommend_num']>=5]
    # mgm_data_5_lt = mgm_data[mgm_data['recommend_num']<5]

    '''ensemble data'''
    for column in diff_list:

        # mgm_3_gt = mgm_data_3_gt[column].value_counts() / len(mgm_data_3_gt) * 100
        # mgm_3_lt = mgm_data_3_lt[column].value_counts() / len(mgm_data_3_lt) * 100
        # mgm_4_gt = mgm_data_4_gt[column].value_counts() / len(mgm_data_4_gt) * 100
        # mgm_4_lt = mgm_data_4_lt[column].value_counts() / len(mgm_data_4_lt) * 100
        # all=all_data[column].value_counts()/len(all_data)*100
        # mgm_5_gt = mgm_data_5_gt[column].value_counts() / len(mgm_data_5_gt) * 100
        # mgm_5_lt = mgm_data_5_lt[column].value_counts() / len(mgm_data_5_lt) * 100
        #
        # mgm_3_gt = mgm_3_gt.reset_index()
        # mgm_3_gt[column] = mgm_3_gt[column].apply(lambda x: remove_2_xiaoshu(x))
        # mgm_3_gt['index'] = mgm_3_gt['index'].astype(np.str)
        # label_mgm_3_gt = mgm_3_gt['index'].tolist()
        # data_mgm_3_gt= mgm_3_gt[column].tolist()
        #
        # mgm_3_lt = mgm_3_lt.reset_index()
        # mgm_3_lt[column] = mgm_3_lt[column].apply(lambda x: remove_2_xiaoshu(x))
        # mgm_3_lt['index'] = mgm_3_lt['index'].astype(np.str)
        # label_mgm_3_lt = mgm_3_lt['index'].tolist()
        # data_mgm_3_lt= mgm_3_lt[column].tolist()

        fig_data_list=[]
        fig_label_set=set()
        for data in data_list:
            dd=data[column].value_counts() / len(data) * 100
            dd=dd.reset_index()
            dd[column] = dd[column].apply(lambda x: remove_2_xiaoshu(x))
            dd['index'] = dd['index'].astype(np.str)
            dd['index']=dd['index'].apply(lambda x:convert_to_category(x))
            label_dd= set(dd['index'].tolist())
            data_dd = dd[column].tolist()
            fig_data_list.append(data_dd)
            fig_label_set=fig_label_set.union(label_dd)
        # mgm_4_gt = mgm_4_gt.reset_index()
        # mgm_4_gt[column] = mgm_4_gt[column].apply(lambda x: remove_2_xiaoshu(x))
        # mgm_4_gt['index'] = mgm_4_gt['index'].astype(np.str)
        # label_mgm_4_gt = mgm_4_gt['index'].tolist()
        # data_mgm_4_gt= mgm_4_gt[column].tolist()
        #
        # mgm_4_lt = mgm_4_lt.reset_index()
        # mgm_4_lt[column] = mgm_4_lt[column].apply(lambda x: remove_2_xiaoshu(x))
        # mgm_4_lt['index'] = mgm_4_lt['index'].astype(np.str)
        # label_mgm_4_lt= mgm_4_lt['index'].tolist()
        # data_mgm_4_lt= mgm_4_lt[column].tolist()

        # mgm_5_gt = mgm_5_gt.reset_index()
        # mgm_5_gt[column] = mgm_5_gt[column].apply(lambda x: remove_2_xiaoshu(x))
        # mgm_5_gt['index'] = mgm_5_gt['index'].astype(np.str)
        # label_mgm_5_gt = mgm_5_gt['index'].tolist()
        # data_mgm_5_gt= mgm_5_gt[column].tolist()
        #
        # mgm_5_lt = mgm_5_lt.reset_index()
        # mgm_5_lt[column] = mgm_5_lt[column].apply(lambda x: remove_2_xiaoshu(x))
        # mgm_5_lt['index'] = mgm_5_lt['index'].astype(np.str)
        # label_mgm_5_lt = mgm_5_lt['index'].tolist()
        # data_mgm_5_lt= mgm_5_lt[column].tolist()

        '''data label'''
        label_list=list(fig_label_set)

        # label_list = list(set(label_mgm_3_gt).union(set(label_mgm_3_lt)).union(set(label_mgm_4_gt)).union(set(label_mgm_4_lt)).union(set(label_mgm_5_gt)).union(set(label_mgm_5_lt)))

        '''plot figure'''
        chart = Echart(True, theme='macarons')
        chart.use(Title('mgm用户推荐人数为（>=4,<4,整体）对比图', column, x='center'))
        chart.use(Tooltip(trigger='axis'))
        chart.use(Legend(data=nototation_list, position=['center', 'bottom']))
        chart.use(Toolbox(show='true', feature=Feature()))
        chart.use(Axis(param='x', type='category', data=label_list))
        chart.use(Axis(param='y', type='value'))
        for i in range(len(fig_data_list)):
            chart.use(Bar(name=nototation_list[i], data=fig_data_list[i], markPoint=MarkPoint(), markLine=MarkLine()))
        # chart.use(Bar(name='推荐人数>=3人', data=data_mgm_3_gt, markPoint=MarkPoint(), markLine=MarkLine()))
        # chart.use(Bar(name='推荐人数<3人', data=data_mgm_3_lt, markPoint=MarkPoint(), markLine=MarkLine()))
        # chart.use(Bar(name='推荐人数>=4人', data=data_mgm_4_gt, markPoint=MarkPoint(), markLine=MarkLine()))
        # chart.use(Bar(name='推荐人数<4人', data=data_mgm_4_lt, markPoint=MarkPoint(), markLine=MarkLine()))
        # chart.use(Bar(name='推荐人数>=5人', data=data_mgm_5_gt, markPoint=MarkPoint(), markLine=MarkLine()))
        # chart.use(Bar(name='推荐人数<5人', data=data_mgm_5_lt, markPoint=MarkPoint(), markLine=MarkLine()))
        chart.plot()

def main():
    import pandas as pd
    from collections import Counter
    import numpy as np
    from pandas import DataFrame
    from pandas import Series
    plot_caifuduan_figure()
    # data_fir = "D:\\fg_workspace\\caifuduan\\final\\"
    # mgm_data = pd.read_csv(data_fir + "final_version_data.csv")
    # mgm_data = mgm_data[["ecif_id", "recommend_num", "sex", "birth_date", "fposition", "fhighest_education", "customer_level",
    #      "province_name", "city_name", "open_time"]]###
    # all_data = pd.read_csv(data_fir + "MGM_feature_nv.csv")
    # all_data = all_data[
    #     ["ecif_id", "recommend_num", "sex", "birth_date", "fposition", "fhighest_education", "customer_level",
    #      "province_name", "city_name", "open_time"]]
    # for column in all_data.columns.tolist():
    #     all_data.loc[(all_data[column].isnull()), column] = -999
    #
    # mgm_data['open_time'] = mgm_data['open_time'].apply(lambda x: 2017 - int(str(x)[:4]))
    # all_data['open_time'] = all_data['open_time'].apply(lambda x: 2017 - int(str(x)[:4]))
    #
    # mgm_data['age'] = mgm_data['birth_date'].apply(lambda x: 2017 - int(str(x)[:4]))
    # all_data['age'] = all_data['birth_date'].apply(lambda x: 2017 - int(str(x)[:4]))
    #
    # mgm_data.drop('birth_date', axis=1, inplace=True)
    # all_data.drop('birth_date', axis=1, inplace=True)
    #
    # mgm_data_2 = mgm_data[(mgm_data['recommend_num'] <= 2) & (mgm_data['recommend_num'] >= 1)]
    # mgm_data_3 = mgm_data[mgm_data['recommend_num'] == 3]
    # mgm_data_4 = mgm_data[mgm_data['recommend_num'] == 4]
    # mgm_data_4_up = mgm_data[mgm_data['recommend_num'] > 4]
    #
    # all_data_2 = all_data[(all_data['recommend_num'] <= 2) & (all_data['recommend_num'] >= 1)]
    # all_data_3 = all_data[all_data['recommend_num'] == 3]
    # all_data_4 = all_data[all_data['recommend_num'] == 4]
    # all_data_4_up = all_data[all_data['recommend_num'] > 4]
    #
    # # diff_list = ["age", "fposition", "fhighest_education", "customer_level", "province_name", "city_name",
    # #              "open_time"]
    # diff_list=["customer_level"]
    #
    # for column in diff_list:
    #     mgm= mgm_data_2[column].value_counts() / len(mgm_data_2) * 100
    #     all = all_data_2[column].value_counts() / len(all_data_2) * 100
    #
    #     mgm[column]=mgm[column].apply(lambda x:round(x,2))
    #     all[column] = all[column].apply(lambda x: round(x, 2))
    #
    #
    #     mgm = mgm.reset_index()
    #     label_list_mgm = mgm['index'].tolist()
    #     data_list_mgm = mgm[column].tolist()
    #
    #
    #     all = all.reset_index()
    #     label_list_all = all['index'].tolist()
    #     data_list_all = all[column].tolist()
    #
    #     label_list = list(set(label_list_mgm).union(set(label_list_all)))
    #     print label_list
    #     print data_list_mgm
    #     print data_list_all

    """柱状图实例"""
    # diff_list = ["sex", "age", "ftrade", "fhighest_education", "customer_level", "province_name", "audit_status"]

    # sex_1 = ['1', '0']
    #
    # sex_mgm_1 = ['61.05', '38.95']
    # sex_all_1 = ['60.89', '39.11']
    # age_1 = ['<=30', '<=60', '>60', '<=40', '<=50']
    #
    # age_mgm_1 = ['31.43', '25.13', '20.06', '18.64', '4.73']
    # age_all_1 = ['28.79', '23.09', '21.55', '20.10', '6.48']
    # ftrade_1 = ['19.0', '0.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '1.0', '2.0', '13.0', '20.0', '8.0', '4.0',
    #             '11.0', '17.0', '16.0', '9.0', '-10.0', '5.0', '10.0', '21.0', '15.0', '14.0', '18.0']
    #
    # ftrade_mgm_1 = ['47.14', '18.40', '5.71', '3.61', '2.93', '2.39', '1.90', '1.90', '1.85', '1.81', '1.76', '1.61',
    #                 '1.46', '1.12', '1.12', '1.07', '0.93', '0.93', '0.63', '0.63', '0.54', '0.49', '0.05']
    # ftrade_all_1 = ['94.82', '1.58', '0.51', '0.50', '0.33', '0.29', '0.21', '0.18', '0.17', '0.16', '0.15', '0.15',
    #                 '0.15', '0.14', '0.10', '0.09', '0.09', '0.08', '0.07', '0.07', '0.06', '0.05', '0.04', '0.00']
    # fhighest_education_1 = ['1.0', '0.0', '-999.0', '2.0']
    #
    # fhighest_education_mgm_1 = ['91.61', '6.69', '1.12', '0.59']
    # fhighest_education_all_1 = ['99.28', '0.57', '0.11', '0.04']
    # customer_level_1 = ['3', '<=2']
    #
    # customer_level_mgm_1 = ['84.43', '15.57']
    # customer_level_all_1 = ['93.81', '6.19']
    # province_name_1 = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm_1 = ['23.67', '22.16', '17.96', '16.69', '10.40', '9.13']
    # province_name_all_1 = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # audit_status_1 = ['1', '3', '5', '4', '6']
    #
    # audit_status_mgm_1 = ['99.32', '0.34', '0.34']
    # audit_status_all_1 = ['98.81', '0.73', '0.33', '0.12', '0.01']
    #
    # sex_2 = ['1', '0']
    #
    # sex_mgm_2 = ['64.01', '35.99']
    # sex_all_2 = ['60.89', '39.11']
    # age_2 = ['<=30', '<=60', '>60', '<=40', '<=50']
    #
    # age_mgm_2 = ['32.57', '24.10', '20.03', '19.22', '4.07']
    # age_all_2 = ['28.79', '23.09', '21.55', '20.10', '6.48']
    # ftrade_2 = ['19.0', '0.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '1.0', '2.0', '13.0', '5.0', '8.0', '4.0', '11.0',
    #             '17.0', '16.0', '9.0', '-10.0', '20.0', '10.0', '21.0', '15.0', '14.0', '18.0']
    #
    # ftrade_mgm_2 = ['47.56', '18.57', '6.19', '3.91', '2.93', '2.28', '2.12', '1.95', '1.79', '1.63', '1.63', '1.30',
    #                 '1.30', '1.14', '1.14', '0.98', '0.98', '0.81', '0.65', '0.49', '0.49', '0.16']
    # ftrade_all_2 = ['94.82', '1.58', '0.51', '0.50', '0.33', '0.29', '0.21', '0.18', '0.17', '0.16', '0.15', '0.15',
    #                 '0.15', '0.14', '0.10', '0.09', '0.09', '0.08', '0.07', '0.07', '0.06', '0.05', '0.04', '0.00']
    # fhighest_education_2 = ['1.0', '0.0', '-999.0', '2.0']
    #
    # fhighest_education_mgm_2 = ['92.18', '6.51', '1.14', '0.16']
    # fhighest_education_all_2 = ['99.28', '0.57', '0.11', '0.04']
    # customer_level_2 = ['3', '<=2']
    #
    # customer_level_mgm_2 = ['83.71', '16.29']
    # customer_level_all_2 = ['93.81', '6.19']
    # province_name_2 = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm_2 = ['23.45', '21.66', '20.85', '14.33', '12.54', '7.17']
    # province_name_all_2 = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # audit_status_2 = ['1', '3', '5', '4', '6']
    #
    # audit_status_mgm_2 = ['99.02', '0.65', '0.16', '0.16']
    # audit_status_all_2 = ['98.81', '0.73', '0.33', '0.12', '0.01']
    #
    # sex_3 = ['1', '0']
    #
    # sex_mgm_3 = ['63.64', '36.36']
    # sex_all_3 = ['60.89', '39.11']
    # age_3 = ['<=30', '<=60', '>60', '<=40', '<=50']
    #
    # age_mgm_3 = ['33.45', '27.64', '19.27', '13.45', '6.18']
    # age_all_3 = ['28.79', '23.09', '21.55', '20.10', '6.48']
    # ftrade_3 = ['19.0', '0.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '1.0', '2.0', '13.0', '5.0', '8.0', '4.0', '11.0',
    #             '17.0', '16.0', '9.0', '-10.0', '20.0', '10.0', '21.0', '15.0', '14.0', '18.0']
    #
    # ftrade_mgm_3 = ['48.73', '17.09', '6.91', '4.36', '3.64', '2.55', '2.18', '2.18', '2.18', '1.82', '1.82', '1.45',
    #                 '1.09', '1.09', '0.73', '0.73', '0.36', '0.36', '0.36', '0.36']
    # ftrade_all_3 = ['94.82', '1.58', '0.51', '0.50', '0.33', '0.29', '0.21', '0.18', '0.17', '0.16', '0.15', '0.15',
    #                 '0.15', '0.14', '0.10', '0.09', '0.09', '0.08', '0.07', '0.07', '0.06', '0.05', '0.04', '0.00']
    # fhighest_education_3 = ['1.0', '0.0', '-999.0', '2.0']
    #
    # fhighest_education_mgm_3 = ['91.27', '6.91', '1.45', '0.36']
    # fhighest_education_all_3 = ['99.28', '0.57', '0.11', '0.04']
    # customer_level_3 = ['3', '<=2']
    #
    # customer_level_mgm_3 = ['82.55', '17.45']
    # customer_level_all_3 = ['93.81', '6.19']
    # province_name_3 = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm_3 = ['29.45', '20.00', '19.27', '13.82', '9.45', '8.00']
    # province_name_all_3 = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # audit_status_3 = ['1', '3', '5', '4', '6']
    #
    # audit_status_mgm_3 = ['99.64', '0.36']
    # audit_status_all_3 = ['98.81', '0.73', '0.33', '0.12', '0.01']
    #
    # sex_4 = ['1', '0']
    #
    # sex_mgm_4 = ['75.89', '24.11']
    # sex_all_4 = ['60.89', '39.11']
    # age_4 = ['<=30', '<=60', '>60', '<=40', '<=50']
    #
    # age_mgm_4 = ['33.04', '25.00', '19.64', '15.18', '7.14']
    # age_all_4 = ['28.79', '23.09', '21.55', '20.10', '6.48']
    # ftrade_4 = ['19.0', '0.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '1.0', '2.0', '13.0', '5.0', '8.0', '4.0', '11.0',
    #             '17.0', '16.0', '9.0', '-10.0', '20.0', '10.0', '21.0', '15.0', '14.0', '18.0']
    #
    # ftrade_mgm_4 = ['48.21', '10.71', '6.25', '5.36', '4.46', '4.46', '3.57', '2.68', '2.68', '1.79', '1.79', '1.79',
    #                 '0.89', '0.89', '0.89', '0.89', '0.89', '0.89', '0.89']
    # ftrade_all_4 = ['94.82', '1.58', '0.51', '0.50', '0.33', '0.29', '0.21', '0.18', '0.17', '0.16', '0.15', '0.15',
    #                 '0.15', '0.14', '0.10', '0.09', '0.09', '0.08', '0.07', '0.07', '0.06', '0.05', '0.04', '0.00']
    # fhighest_education_4 = ['1.0', '0.0', '2.0', '-999.0']
    #
    # fhighest_education_mgm_4 = ['91.96', '7.14', '0.89']
    # fhighest_education_all_4 = ['99.28', '0.57', '0.11', '0.04']
    # customer_level_4 = ['3', '<=2']
    #
    # customer_level_mgm_4 = ['87.50', '12.50']
    # customer_level_all_4 = ['93.81', '6.19']
    # province_name_4 = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm_4 = ['26.79', '23.21', '19.64', '14.29', '9.82', '6.25']
    # province_name_all_4 = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # audit_status_4 = ['1', '3', '5', '4', '6']
    #
    # audit_status_mgm_4 = ['99.11', '0.89']
    # audit_status_all_4 = ['98.81', '0.73', '0.33', '0.12', '0.01']
    #
    # sex_4_up = ['1', '0']
    #
    # sex_mgm_4_up = ['64.41', '35.59']
    # sex_all_4_up = ['60.89', '39.11']
    # age_4_up = ['<=30', '<=60', '>60', '<=40', '<=50']
    #
    # age_mgm_4_up = ['31.53', '27.48', '20.72', '13.51', '6.76']
    # age_all_4_up = ['28.79', '23.09', '21.55', '20.10', '6.48']
    # ftrade_4_up = ['1.0', '0.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '19.0', '2.0', '13.0', '5.0', '8.0', '4.0',
    #                '11.0', '17.0', '16.0', '9.0', '-10.0', '20.0', '10.0', '21.0', '15.0', '14.0', '18.0']
    #
    # ftrade_mgm_4_up = ['43.24', '14.86', '6.31', '4.95', '4.05', '4.05', '4.05', '2.70', '1.80', '1.80', '1.80', '1.35',
    #                    '1.35', '1.35', '1.35', '0.90', '0.90', '0.90', '0.90', '0.45', '0.45', '0.45']
    # ftrade_all_4_up = ['94.82', '1.58', '0.51', '0.50', '0.33', '0.29', '0.21', '0.18', '0.17', '0.16', '0.15', '0.15',
    #                    '0.15', '0.14', '0.10', '0.09', '0.09', '0.08', '0.07', '0.07', '0.06', '0.05', '0.04', '0.00']
    # fhighest_education_4_up = ['1.0', '0.0', '-999.0', '2.0']
    #
    # fhighest_education_mgm_4_up = ['91.89', '4.95', '2.25', '0.90']
    # fhighest_education_all_4_up = ['99.28', '0.57', '0.11', '0.04']
    # customer_level_4_up = ['3', '<=2']
    #
    # customer_level_mgm_4_up = ['76.13', '23.87']
    # customer_level_all_4_up = ['93.81', '6.19']
    # province_name_4_up = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm_4_up = ['25.68', '19.82', '17.57', '15.32', '11.26', '10.36']
    # province_name_all_4_up = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # audit_status_4_up = ['1', '3', '5', '4', '6']
    #
    # audit_status_mgm_4_up = ['100.00']
    # audit_status_all_4_up = ['98.81', '0.73', '0.33', '0.12', '0.01']


    # sex_4_up = ['1', '0']
    #
    # sex_mgm_4_up = ['55.81', '44.19']
    # sex_all_4_up = ['59.79', '40.21']
    # age_4_up = ['<=30', '<=60', '>60', '<=40', '<=50']
    #
    # age_mgm_4_up = ['32.56', '24.42', '22.09', '12.79', '8.14']
    # age_all_4_up = ['29.51', '22.85', '22.50', '16.90', '8.25']
    # ftrade_4_up = ['1.0', '0.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '19.0', '2.0', '13.0', '5.0', '10.0', '21.0',
    #                '11.0', '17.0', '16.0', '9.0', '-10.0', '8.0', '4.0', '15.0', '14.0', '18.0']
    #
    # ftrade_mgm_4_up = ['70.93', '6.98', '3.49', '2.33', '2.33', '2.33', '2.33', '2.33', '1.16', '1.16', '1.16', '1.16',
    #                    '1.16', '1.16']
    # ftrade_all_4_up = ['97.88', '0.68', '0.26', '0.20', '0.12', '0.11', '0.09', '0.06', '0.06', '0.05', '0.05', '0.05',
    #                    '0.05', '0.05', '0.04', '0.04', '0.04', '0.04', '0.04', '0.03', '0.02', '0.02', '0.01']
    # fhighest_education_4_up = ['-999.0', '2.0', '1.0']
    #
    # fhighest_education_mgm_4_up = ['97.67', '2.33']
    # fhighest_education_all_4_up = ['99.81', '0.16', '0.03']
    # customer_level_4_up = ['3', '<=2']
    #
    # customer_level_mgm_4_up = ['82.56', '17.44']
    # customer_level_all_4_up = ['95.00', '5.00']
    # province_name_4_up = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm_4_up = ['25.58', '19.77', '15.12', '15.12', '13.95', '10.47']
    # province_name_all_4_up = ['28.58', '19.29', '15.55', '14.77', '13.55', '8.27']
    # audit_status_4_up = ['1', '3', '5', '4', '6']
    #
    # audit_status_mgm_4_up = ['100.00']
    # audit_status_all_4_up = ['99.46', '0.43', '0.08', '0.02', '0.02']

    # data_mgm_list_1 = [sex_mgm_1,age_mgm_1, ftrade_mgm_1, fhighest_education_mgm_1, customer_level_mgm_1, province_name_mgm_1,
    #                  audit_status_mgm_1]
    #
    # data_mgm_list_2 = [sex_mgm_2,age_mgm_2, ftrade_mgm_2, fhighest_education_mgm_2, customer_level_mgm_2, province_name_mgm_2,
    #                    audit_status_mgm_2]
    #
    # data_mgm_list_3 = [sex_mgm_3,age_mgm_3, ftrade_mgm_3, fhighest_education_mgm_3, customer_level_mgm_3, province_name_mgm_3,
    #                    audit_status_mgm_3]
    #
    # data_mgm_list_4 = [sex_mgm_4,age_mgm_4, ftrade_mgm_4, fhighest_education_mgm_4, customer_level_mgm_4, province_name_mgm_4,
    #                    audit_status_mgm_4]

    # data_mgm_list_4_up = [sex_mgm_4_up,age_mgm_4_up, ftrade_mgm_4_up, fhighest_education_mgm_4_up, customer_level_mgm_4_up, province_name_mgm_4_up,
    #                    audit_status_mgm_4_up]
    #
    #
    # data_all_list = [sex_all_4_up,age_all_4_up, ftrade_all_4_up, fhighest_education_all_4_up, customer_level_all_4_up, province_name_all_4_up,
    #                  audit_status_all_4_up]
    # sex = list(set(sex_4_up))
    # age=list(set(age_4_up))
    # ftrade = list(set(ftrade_4_up))
    # fhighest_education = list(set(fhighest_education_4_up))
    # customer_level = list(set(customer_level_4_up))
    # province_name = list(set(province_name_4_up))
    # audit_status = list(set(audit_status_4_up))
    #
    #
    # data_label = [sex,age, ftrade, fhighest_education, customer_level, province_name,
    #                            audit_status]
    # for i in range(len(diff_list)):
    #     chart = Echart(True, theme='macarons')
    #     chart.use(Title('mgm用户vs所有用户在推荐人数为（4+）且mob<2对比图', diff_list[i], x='center'))
    #     chart.use(Tooltip(trigger='axis'))
    #     chart.use(Legend(data=['推荐人数（4+）人','整体用户'], position=['center', 'bottom']))
    #     chart.use(Toolbox(show='true', feature=Feature()))
    #     chart.use(Axis(param='x', type='category', data=data_label[i]))
    #     chart.use(Axis(param='y', type='value'))
    #     # itemStyle=ItemStyle(normal="{'label': {'show': 'true', 'position':'bottom'}}")
    #     chart.use(Bar(name='推荐人数（4+）人', data=data_mgm_list_4_up[i], markPoint=MarkPoint(), markLine=MarkLine()))
    #     chart.use(Bar(name='整体用户', data=data_all_list[i], markPoint=MarkPoint(), markLine=MarkLine()))
    #     chart.plot()

    # diff_list = ["sex","age", "fposition", "fhighest_education", "customer_level", "province_name", "open_time"]

    # age = ['1', '0', '3', '2', '4']
    #
    # age_mgm = ['31.69', '24.90', '20.05', '18.78', '4.58']
    # age_all = ['28.79', '23.09', '21.55', '20.12', '6.45']
    # fposition = ['15.0', '1.0', '8.0', '0.0', '23.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '19.0', '13.0', '5.0',
    #              '25.0', '14.0', '11.0', '17.0', '22.0', '16.0', '9.0']
    #
    # fposition_mgm = ['87.83', '9.65', '0.79', '0.38', '0.23', '0.15', '0.15', '0.11', '0.11', '0.11', '0.11', '0.08',
    #                  '0.08', '0.04', '0.04', '0.04', '0.04', '0.04', '0.04']
    # fposition_all = ['98.99', '0.76', '0.07', '0.03', '0.03', '0.02', '0.02', '0.01', '0.01', '0.01', '0.01', '0.01',
    #                  '0.01', '0.01', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00']
    # fhighest_education = ['1.0', '0.0', '-999.0', '2.0']
    #
    # fhighest_education_mgm = ['91.74', '6.65', '1.13', '0.49']
    # fhighest_education_all = ['99.28', '0.57', '0.11', '0.04']
    # customer_level = ['3', '<=2']
    #
    # customer_level_mgm = ['84.27', '15.73']
    # customer_level_all = ['93.81', '6.19']
    # province_name = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm = ['23.62', '22.04', '18.63', '16.15', '10.89', '8.67']
    # province_name_all = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # open_time = ['1', '0', '3', '2', '4', '5+']
    #
    # open_time_mgm = ['23.02', '21.93', '21.63', '17.50', '10.70', '5.22']
    # open_time_all = ['24.72', '21.84', '20.44', '18.58', '10.38', '4.04']

    # age = ['1', '0', '3', '2', '4']
    #
    # age_mgm = ['33.45', '27.64', '19.27', '13.45', '6.18']
    # age_all = ['28.79', '23.09', '21.55', '20.12', '6.45']
    # fposition = ['15.0', '1.0', '8.0', '0.0', '23.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '19.0', '13.0', '5.0',
    #              '25.0', '14.0', '11.0', '22.0', '17.0', '16.0', '9.0']
    #
    # fposition_mgm = ['89.82', '5.82', '1.09', '0.73', '0.36', '0.36', '0.36', '0.36', '0.36', '0.36', '0.36']
    # fposition_all = ['98.99', '0.76', '0.07', '0.03', '0.03', '0.02', '0.02', '0.01', '0.01', '0.01', '0.01', '0.01',
    #                  '0.01', '0.01', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00']
    # fhighest_education = ['1.0', '0.0', '-999.0', '2.0']
    #
    # fhighest_education_mgm = ['91.27', '6.91', '1.45', '0.36']
    # fhighest_education_all = ['99.28', '0.57', '0.11', '0.04']
    # customer_level = ['3', '<=2']
    #
    # customer_level_mgm = ['82.55', '17.45']
    # customer_level_all = ['93.81', '6.19']
    # province_name = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm = ['29.45', '20.00', '19.27', '13.82', '9.45', '8.00']
    # province_name_all = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # open_time = ['1', '0', '3', '2', '4', '5+']
    #
    # open_time_mgm = ['24.36', '23.64', '23.27', '14.91', '8.73', '5.09']
    # open_time_all = ['24.72', '21.84', '20.44', '18.58', '10.38', '4.04']

    # age = ['1', '0', '3', '2', '4']
    #
    # age_mgm = ['33.04', '25.00', '19.64', '15.18', '7.14']
    # age_all = ['28.79', '23.09', '21.55', '20.12', '6.45']
    # fposition = ['15.0', '1.0', '8.0', '0.0', '23.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '19.0', '13.0', '5.0',
    #              '25.0', '14.0', '11.0', '22.0', '17.0', '16.0', '9.0']
    #
    # fposition_mgm = ['89.29', '6.25', '2.68', '0.89', '0.89']
    # fposition_all = ['98.99', '0.76', '0.07', '0.03', '0.03', '0.02', '0.02', '0.01', '0.01', '0.01', '0.01', '0.01',
    #                  '0.01', '0.01', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00']
    # fhighest_education = ['1.0', '0.0', '2.0', '-999.0']
    #
    # fhighest_education_mgm = ['91.96', '7.14', '0.89']
    # fhighest_education_all = ['99.28', '0.57', '0.11', '0.04']
    # customer_level = ['3', '<=2']
    #
    # customer_level_mgm = ['87.50', '12.50']
    # customer_level_all = ['93.81', '6.19']
    # province_name = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm = ['26.79', '23.21', '19.64', '14.29', '9.82', '6.25']
    # province_name_all = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # open_time = ['1', '0', '3', '2', '4', '5+']
    #
    # open_time_mgm = ['25.00', '23.21', '19.64', '18.75', '8.04', '5.36']
    # open_time_all = ['24.72', '21.84', '20.44', '18.58', '10.38', '4.04']

    # age = ['1', '0', '3', '2', '4']
    #
    # age_mgm = ['31.53', '27.48', '20.72', '13.51', '6.76']
    # age_all = ['28.79', '23.09', '21.55', '20.12', '6.45']
    # fposition = ['15.0', '1.0', '8.0', '0.0', '23.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '19.0', '13.0', '5.0',
    #              '25.0', '14.0', '11.0', '22.0', '17.0', '16.0', '9.0']
    #
    # fposition_mgm = ['91.44', '4.95', '1.80', '0.90', '0.45', '0.45']
    # fposition_all = ['98.99', '0.76', '0.07', '0.03', '0.03', '0.02', '0.02', '0.01', '0.01', '0.01', '0.01', '0.01',
    #                  '0.01', '0.01', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00']
    # fhighest_education = ['1.0', '0.0', '-999.0', '2.0']
    #
    # fhighest_education_mgm = ['91.89', '4.95', '2.25', '0.90']
    # fhighest_education_all = ['99.28', '0.57', '0.11', '0.04']
    # customer_level = ['3', '<=2']
    #
    # customer_level_mgm = ['76.13', '23.87']
    # customer_level_all = ['93.81', '6.19']
    # province_name = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm = ['25.68', '19.82', '17.57', '15.32', '11.26', '10.36']
    # province_name_all = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # open_time = ['1', '0', '3', '2', '4', '5+']
    #
    # open_time_mgm = ['25.68', '25.23', '19.82', '19.37', '5.41', '4.50']
    # open_time_all = ['24.72', '21.84', '20.44', '18.58', '10.38', '4.04']


    # sex = ['1', '0']
    #
    # sex_mgm = ['68.26', '31.74']
    # sex_all = ['60.89', '39.11']
    # age = ['1', '0', '3', '2', '4']
    #
    # age_mgm = ['29.34', '29.34', '18.86', '15.57', '6.89']
    # age_all = ['28.79', '23.09', '21.55', '20.12', '6.45']
    # fposition = ['15.0', '1.0', '8.0', '0.0', '23.0', '-999.0', '7.0', '12.0', '3.0', '6.0', '19.0', '13.0', '5.0',
    #              '25.0', '14.0', '11.0', '22.0', '17.0', '16.0', '9.0']
    #
    # fposition_mgm = ['90.72', '5.39', '2.10', '0.60', '0.60', '0.30', '0.30']
    # fposition_all = ['98.99', '0.76', '0.07', '0.03', '0.03', '0.02', '0.02', '0.01', '0.01', '0.01', '0.01', '0.01',
    #                  '0.01', '0.01', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00']
    # fhighest_education = ['1.0', '0.0', '-999.0', '2.0']
    #
    # fhighest_education_mgm = ['91.92', '5.69', '1.80', '0.60']
    # fhighest_education_all = ['99.28', '0.57', '0.11', '0.04']
    # customer_level = ['3', '<=2']
    #
    # customer_level_mgm = ['79.94', '20.06']
    # customer_level_all = ['93.81', '6.19']
    # province_name = ['山东省', '江苏省', '上海市', 'other', '北京市', '浙江省']
    #
    # province_name_mgm = ['24.85', '20.66', '19.76', '14.97', '10.78', '8.98']
    # province_name_all = ['25.09', '19.19', '18.19', '14.35', '14.17', '9.01']
    # open_time = ['1', '0', '3', '2', '4', '5+']
    #
    # open_time_mgm = ['25.15', '24.85', '19.46', '19.46', '6.29', '4.79']
    # open_time_all = ['24.72', '21.84', '20.44', '18.58', '10.38', '4.04']
    #
    #
    #
    # data_mgm_list=[sex_mgm,age_mgm,fposition_mgm,fhighest_education_mgm,customer_level_mgm,province_name_mgm,open_time_mgm]
    # data_all_list = [sex_all,age_all, fposition_all, fhighest_education_all, customer_level_all, province_name_all,
    #                  open_time_all]
    #
    # data_label=[sex,age,fposition,fhighest_education,customer_level,province_name,open_time]
    #
    # for i in range(len(diff_list)):
    #     chart = Echart(True, theme='macarons')
    #     chart.use(Title('mgm用户vs所有用户(推荐人数4+)', diff_list[i], x='center'))
    #     chart.use(Tooltip(trigger='axis'))
    #     chart.use(Legend(data=['mgm用户','所有用户'], position=['center', 'bottom']))
    #     chart.use(Toolbox(show='true', feature=Feature()))
    #     chart.use(Axis(param='x', type='category', data=data_label[i]))
    #     chart.use(Axis(param='y', type='value'))
    #     # itemStyle=ItemStyle(normal="{'label': {'show': 'true', 'position':'bottom'}}")
    #     chart.use(Bar(name='mgm用户', data=data_mgm_list[i], markPoint=MarkPoint(), markLine=MarkLine()))
    #     chart.use(Bar(name='所有用户', data=data_all_list[i], markPoint=MarkPoint(), markLine=MarkLine()))
    #     chart.plot()




    """Map图实例"""
    # path="C:\\Users\\Administrator.201611210178-\\Desktop\\提交的项目\\echarts_project\\"
    # name="智享以上客户分布图"
    # chart=Echart(False)
    # chart.use(Title('智享以上客户分布图','智享以上客户分布图','center'))
    # # chart.use(Bar(name='China',data=[2,3,4,5]))
    # # chart.use(Axis(data=['Nov','Dec','Jan','Feb']))
    # chart.use(Tooltip())
    # chart.use(VisualMap([0,2500]))
    # chart.use(Legend(['省'],'vertical',('left', 'top')))
    # chart.use(DataRange([0,7600],['left','bottom']))
    # feature=Feature()
    # chart.use(Toolbox('vertical',['right','center'],'true',feature))
    #
    # mapTypeControl=MapTypeControl()
    # chart.use(RoamController(mapTypeControl))
    # itemStyle=ItemStyle()
    #
    # data=pd.read_csv("../df.txt")
    # column_list = data.columns.tolist()
    # if len(column_list) == 2 and column_list != ['name', 'value']:
    #     data.columns = ['name', 'value']
    # data_list = data.to_dict(orient='records')
    # chart.use(Map('省','china',itemStyle,data_list))
    # chart.plot()



    '''折线图的实例'''
    # chart=Echart(theme='gray')###macarons
    # chart.use(Title('某楼盘销售情况','纯属虚构'))
    # chart.use(Tooltip(trigger='axis'))
    # chart.use(Legend(data=['意向','预购','成交']))
    # chart.use(Toolbox(show='true', feature=Feature()))
    # chart.use(Axis(param='x', type='category',
    #                data=['周一','周二','周三','周四','周五','周六','周日'],boundaryGap='false'))
    # chart.use(Axis(param='y', type='value'))
    # itemStyle={"normal": {"areaStyle": {"type": 'default'}}}
    # chart.use(Line(name='成交', data=[10, 12, 21, 54, 260, 830, 710],itemStyle=itemStyle,
    #               smooth='true'))
    # chart.use(Line(name='预购', data=[30, 182, 434, 791, 390, 30, 10],itemStyle=itemStyle,
    #                smooth='true'))
    # chart.use(Line(name='意向', data=[1320, 1132, 601, 234, 120, 90, 20],itemStyle=itemStyle,
    #                smooth='true'))
    # chart.plot()
    # path="D:\\fg_workspace\\caifuduan\\final\\"
    # data = load_data(path+"final_version_data.csv")
    #
    # hobby_list = ["kyc_hobby", "app_hobby", "activity_hobby", "yl_hobby"]
    # hobby = [""] * data.shape[0]
    # for i in range(0, data.shape[0]):
    #     hobby[i] = ""
    #     for j in hobby_list:
    #         hobby[i] += data[j][i]
    #         hobby[i] += '|'
    # data['hobby'] = hobby

    # province
    # data_1 = data[data["province_name"] == "浙江省"]
    # data_1 = data[data["province_name"] == "北京市"]
    # data_1 = data[data["province_name"] == "上海市"]
    # data_1 = data[data["province_name"] == "山东省"]
    # data_1 = data[data["province_name"] == "江苏省"]
    # ho = map(lambda x: x.decode("utf-8"), df_to_list(data["hobby"]))
    # cntdict = Counter(ho)
    # cnttuple = map(lambda x: (x[0], x[1] * 1.0), cntdict.most_common(11))
    # for i in cnttuple:
    #     print i[0], i[1]
    # barplot(ho, "all_fn.jpg", 10, data.shape[0])
    # pieplot(ho, "all_fn_pie.jpg", 10, data.shape[0])
    """
    all
    fn= map(lambda x: x.decode("utf-8"), df_to_list(data["hobby"]))
    barplot(fn, "all_fn.jpg", 10, data.shape[0])
    pieplot(fn, "all_fn_pie.jpg", 10, data.shape[0])
    cntdict = Counter(fn)
    cnttuple = map(lambda x: (x[0], x[1]*1.0), cntdict.most_common(10))
    for i in cnttuple:
        print i[0],i[1]
    """

    """柱状图|条形图实例"""
    # chart = Echart(theme='macarons')
    # chart.use(Tooltip(trigger='axis',axisPointer={type:'item'}))
    # chart.use(Legend(data=['mgm用户','全部用户']))
    # chart.use(Toolbox(show='true',feature=Feature(),orient='vertical',x='right',y='center'))
    # chart.use(Axis(param='x',type='category',data=['1','2','3','4','4+']))
    # chart.use(Axis(param='y',type='value'))
    # itemStyle=ItemStyle(normal="{label : {show: true, position:'top'}}")
    # print itemStyle.json
    # chart.use(Bar(name='mgm用户',itemStyle=itemStyle,data=[31.31, 9.38, 4.20, 1.71, 3.39]))
    # chart.use(Bar(name='全部用户',itemStyle=itemStyle,data=[5.03, 1.52, 0.67, 0.30, 0.56]))
    # print chart.json




if __name__=='__main__':
    main()

