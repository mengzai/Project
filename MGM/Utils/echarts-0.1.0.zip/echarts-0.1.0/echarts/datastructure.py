# coding: utf-8

"""
    echarts.datastructure
    ~~~~~~~~~~~~~~~~~~~~~

    Datastructure for describing the chart types.
"""

from option import Series
from option import Base


class Line(Series):
    """
    Line component
    """
    def __init__(self,name=None, mapType=None,itemStyle=None,data=None,markPoint=None,markLine=None,**kwargs):
        super(Line, self).__init__(_type='line', name=name, mapType=mapType,itemStyle=itemStyle,data=data,markPoint=markPoint,markLine=markLine,**kwargs)

class Bar(Series):
    " Bar interface"
    def __init__(self,name=None, mapType=None,itemStyle=None,data=None,markPoint=None,markLine=None,**kwargs):
        super(Bar, self).__init__(_type='bar', name=name, mapType=mapType,itemStyle=itemStyle,data=data,markPoint=markPoint,markLine=markLine,**kwargs)
    # def __init__(self, name=None, data=None, **kwargs):
    #     super(Bar, self).__init__('bar', name=name, data=data, **kwargs)

class Pie(Series):
    " Pie interface"
    def __init__(self,name=None, mapType=None,itemStyle=None,data=None,markPoint=None,markLine=None,**kwargs):
        super(Pie, self).__init__(_type='pie', name=name, mapType=mapType,itemStyle=itemStyle,data=data,markPoint=markPoint,markLine=markLine,**kwargs)
    # def __init__(self, name=None, data=None, **kwargs):
    #     super(Pie, self).__init__('pie', name=name, data=data, **kwargs)
    
class Scatter(Series):
    " Scatter component"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Scatter, self).__init__(_type='scatter', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class EffectScatter(Series):
    " EffectScatter interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(EffectScatter, self).__init__(_type='effectscatter', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Radar(Series):
    " Radar interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Radar, self).__init__(_type='radar', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Treemap(Series):
    " Treemap interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Treemap, self).__init__(_type='treemap', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Boxplot(Series):
    " Boxplot interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Boxplot, self).__init__(_type='boxplot', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Candlestick(Series):
    " Candlestick interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Candlestick, self).__init__(_type='candlestick', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Heatmap(Series):
    " Heatmap interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Heatmap, self).__init__(_type='heatmap', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Map(Series):
    " Map interface"
    def __init__(self, name=None, mapType=None,itemStyle=None,data=None,markPoint=None,markLine=None,**kwargs):
        super(Map, self).__init__(_type='map', name=name, mapType=mapType,itemStyle=itemStyle,data=data,markPoint=markPoint,markLine=markLine,**kwargs)
    # def __init__(self, name=None, data=None, **kwargs):
        # super(Map, self).__init__('map', name=name, data=data, **kwargs)

class Parallel(Series):
    " Parallel interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Parallel, self).__init__(_type='parallel', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Lines(Series):
    " Lines interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Lines, self).__init__(_type='lines', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Graph(Series):
    " Graph interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Graph, self).__init__(_type='graph', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Sankey(Series):
    " Sankey interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Sankey, self).__init__(_type='sankey', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Funnel(Series):
    " Funnel interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Funnel, self).__init__(_type='funnel', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Gauge(Series):
    " Gauge interface"
    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Gauge, self).__init__(_type='gauge', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


# The following chart types are only available in echarts 2 version.
class K(Series):
    " K interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(K, self).__init__(_type='k', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Force(Series):
    " Force interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Force, self).__init__(_type='force', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Chord(Series):
    " Chord interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Chord, self).__init__(_type='chord', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Venn(Series):
    " Venn interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Venn, self).__init__(_type='venn', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class Tree(Series):
    " Tree interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(Tree, self).__init__(_type='tree', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class EventRiver(Series):
    " EventRiver interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(EventRiver, self).__init__(_type='eventriver', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


class WordCloud(Series):
    " WordCloud interface"

    def __init__(self, name=None, mapType=None, itemStyle=None, data=None, **kwargs):
        super(WordCloud, self).__init__(_type='wordcloud', name=name, mapType=mapType, itemStyle=itemStyle, data=data, **kwargs)


VERSION_2 = (
    Line, Bar, Scatter, K, Pie, Radar, Chord, Force, Map,
    Gauge, Funnel, EventRiver, Venn, Treemap, Tree, WordCloud, Heatmap
)
VERSION_3 = (
    Line, Bar, Pie, Scatter, EffectScatter, Radar, Treemap, Boxplot,
    Candlestick, Heatmap, Map, Parallel, Lines, Graph, Sankey, Funnel, Gauge
)
VERSION_ALL = tuple(set(VERSION_2).union(set(VERSION_3)))
