# -*- coding: utf-8 -*-
"""
    echarts.html
    ~~~~~~~~~~~~~~
    Options for chart
"""
class Html_text(object):
    """
    Base Class
    Args:object
    Returns:return string text of the classreturn string text of the class
    """
    def html_text(self):
        """JSON stringify format data."""
        str_text="<!DOCTYPE html>\n\
                <html>\n\
                <head>\n\
                    <meta charset='utf-8'>\n\
                    <title>ECharts</title>\n\
                    <script src='https://cdnjs.cloudflare.com/ajax/libs/echarts/2.2.7/echarts-all.js'></script>\n\
                </head>\n\
                <body>\n\
                    <div id='main' style='width: 90vw; height: 90vh;'></div>\n\
                    <script type='text/javascript'>\n\
                        var myChart = echarts.init(document.getElementById('main'),'{{ theme }}')\n\
                        var option = {{ opt }};\n\
                        myChart.setOption(option);\n\
                    </script>\n\
                </body>\n\
                </html>"
        return str_text