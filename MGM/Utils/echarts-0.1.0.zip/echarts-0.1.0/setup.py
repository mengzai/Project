'''
Created on 2017-6-7
@author:FG
'''
from distutils.core import setup
setup(name="echarts",
	 version='0.1.0',
	 description="echarts",
	 author='fg',
	 install_requires=[
          'numpy',
          'json',
		  'pandas',
		  'nose',
		  'webbrowser'
      ],
	 packages=['echarts'],
	)